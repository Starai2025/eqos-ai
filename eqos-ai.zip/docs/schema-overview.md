// EQ-OS Supabase schema reference - see Supabase migration folder for live deployment
// ➕ Annotated schema in /docs/schema-overview.md
